package com.example.demo.controller;

import com.example.demo.entity.TotalMarks;
import com.example.demo.entity.HREvaluation;
import com.example.demo.entity.ManagerEvaluation;
import com.example.demo.entity.TaskEvaluation;
import com.example.demo.model.FinalMarksWeight;
import com.example.demo.model.HREvaluationModel;
import com.example.demo.model.ManagerEvaluationModel;
import com.example.demo.model.TaskEvaluationModel;
import com.example.demo.service.FinalEvaluationService;
import com.example.demo.service.TaskEvaluationService;
import com.example.demo.service.TotalMarksGenerationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/evaluation")
@RequiredArgsConstructor

public class AllEvaluationController {

    private final TaskEvaluationService taskEvaluationService;
    private final FinalEvaluationService finalEvaluationService;
    private final TotalMarksGenerationService totalMarksGenerationService;

    @PostMapping("/task/create/{taskId}/{traineeId}")
    public ResponseEntity<TaskEvaluation> createTaskEvaluation(@RequestBody TaskEvaluationModel taskEvaluation , @PathVariable Long taskId , @PathVariable Long traineeId){
        return taskEvaluationService.createTaskEvaluation(taskEvaluation , taskId , traineeId);
    }

    @PostMapping("/manager/create/{traineeId}")
    public ResponseEntity<ManagerEvaluation> createManagerEvaluation(@RequestBody ManagerEvaluationModel managerEvaluation , @PathVariable Long traineeId){
        return finalEvaluationService.createManagerEvaluation(managerEvaluation , traineeId);
    }

    @PostMapping("/hr/create/{traineeId}")
    public ResponseEntity<HREvaluation> createHrEvaluation(@RequestBody HREvaluationModel hrEvaluation , @PathVariable Long traineeId){
        return finalEvaluationService.createHrEvaluation(hrEvaluation , traineeId);
    }

    @PostMapping("/final/create/{batchId}")
    public ResponseEntity<List<TotalMarks>> createFinalMarksForWholeBatch(@PathVariable Long batchId , @RequestBody FinalMarksWeight finalMarksWeight){
        return totalMarksGenerationService.createFinalMarksForWholeBatch(batchId , finalMarksWeight);
    }

}
