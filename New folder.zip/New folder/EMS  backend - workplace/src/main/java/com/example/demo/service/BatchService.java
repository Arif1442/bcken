package com.example.demo.service;

import com.example.demo.entity.*;
import com.example.demo.model.*;
import com.example.demo.repository.*;
import lombok.*;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor

public class BatchService {

    private final BatchRepository batchRepo;
    private final TraineeRepository traineeRepo;
    private final TrainerRepository trainerRepo;

    public ResponseEntity<Batch> createBatch(BatchCreate batch) {

        if (batchRepo.findByBatchName(batch.getBatchName()) != null) {
            throw new RuntimeException("Batch name not available.");
        }
        else {
            Set<Trainee> newTrainees = new HashSet<>();
            for (Long ids : batch.getTraineeIds()) {
//                if( traineeRepo.findById(ids).isPresent() ){
                newTrainees.add(traineeRepo.findById(ids).get());
//                }
            }
            Set<Trainer> newTrainers = new HashSet<>();
            for (Long ids : batch.getTrainerIds()) {
                newTrainers.add(trainerRepo.findById(ids).get());
            }
            Batch newBatch = Batch.builder()
                    .batchName(batch.getBatchName())
                    .startDate(batch.getStartDate())
                    .trainees(newTrainees)
                    .trainers(newTrainers)
                    .build();
            Batch savedBatch = batchRepo.save(newBatch);

            for( Trainee updatedTrainee : newTrainees ){
                updatedTrainee.setBatchId(savedBatch.getBatchId());
                traineeRepo.save(updatedTrainee);
            }

            for( Trainer updatedTrainer : newTrainers ){
                Set<Long> batches = updatedTrainer.getBatchIds();
                batches.add(savedBatch.getBatchId());
                updatedTrainer.setBatchIds(batches);
                trainerRepo.save(updatedTrainer);
            }

            return new ResponseEntity<>(savedBatch, HttpStatus.CREATED);//return ResponseEntity.ok( batchRepo.save(newBatch) );
        }

    }

    public ResponseEntity<List<Batch>> viewAllBatches() {

        return new ResponseEntity<>( batchRepo.findAll() , HttpStatus.OK);

    }

    public ResponseEntity<Batch> findBatchByBatchId(Long batchId) {

        return new ResponseEntity<>( batchRepo.findById(batchId).orElseThrow() , HttpStatus.OK);

    }

}
